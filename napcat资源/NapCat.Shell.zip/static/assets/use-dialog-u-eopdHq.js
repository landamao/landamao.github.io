import{R as o}from"./react-vendor-jWT2yUdV.js";import{aX as t}from"./index-BYES6ECA.js";const s=()=>o.useContext(t);export{s as u};
