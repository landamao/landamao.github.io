import{g as a,a as e,c as n}from"./gestures-BHM27_l-.js";const s={renderer:n,...e,...a};export{s as d};
